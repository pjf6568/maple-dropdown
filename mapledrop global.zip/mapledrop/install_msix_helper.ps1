Add-AppxPackage .\mapledrop_msix_helper.msix -ExternalLocation $(Get-Location)
